"""
쇼핑검색광고 대시보드 - 데이터 변환기

원본 리포트(엑셀/CSV)를 대시보드용 CSV(shopping_ad_daily.csv, category_daily.csv)로 변환합니다.
두 원본 모두 "매번 전체 누적 기간을 다시 추출"하는 형태이므로, 새 원본을 받을 때마다
그냥 다시 변환해서 기존 CSV를 통째로 교체하면 됩니다. (증분 병합 불필요)
"""

import io
import streamlit as st
import pandas as pd

st.set_page_config(page_title="쇼핑검색광고 데이터 변환기", layout="wide")
st.title("🔄 쇼핑검색광고 데이터 변환기")
st.caption("원본 리포트를 업로드하면 대시보드용 CSV를 만들어 다운로드할 수 있습니다.")

tab1, tab2 = st.tabs(["① 일별 실적 (shopping_ad_daily.csv)", "② 카테고리별 실적 (category_daily.csv)"])


def to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig")


def check_missing_dates(dates: pd.Series) -> list:
    full_range = pd.date_range(dates.min(), dates.max(), freq="D")
    missing = sorted(set(full_range) - set(dates))
    return missing


# ════════════════════════════════════════════════════════════════
# TAB 1: 일별 실적 (일일리포트_쇼핑검색광고_RAW.xlsx)
# ════════════════════════════════════════════════════════════════
with tab1:
    st.markdown("""
    **원본 파일**: `일일리포트_쇼핑검색광고_RAW.xlsx` (네이버 쇼핑검색광고 일일 리포트, 1번째 시트)
    매번 전체 누적 기간이 다시 추출되는 형태이므로, 새로 받은 파일을 그대로 올리면 됩니다.
    """)

    daily_file = st.file_uploader("원본 엑셀 업로드 (.xlsx)", type=["xlsx"], key="daily_upload")

    if daily_file is not None:
        try:
            raw = pd.read_excel(daily_file, sheet_name=0)
        except Exception as e:
            st.error(f"엑셀 읽기 실패: {e}")
            st.stop()

        if "기간_일자+요일" not in raw.columns:
            st.error(
                "'기간_일자+요일' 컬럼을 찾을 수 없습니다. 원본 리포트 형식이 바뀌지 않았는지 확인해주세요.\n\n"
                f"현재 컬럼: {list(raw.columns)}"
            )
            st.stop()

        def _parse_date(s):
            date_part = str(s).split(" ")[0]
            return pd.to_datetime(date_part, format="%y-%m-%d")

        raw["date"] = raw["기간_일자+요일"].apply(_parse_date)
        result = raw.sort_values("date").reset_index(drop=True)

        st.success(f"변환 완료: {len(result):,}행 · {result['date'].min().date()} ~ {result['date'].max().date()}")

        missing = check_missing_dates(result["date"])
        if missing:
            st.warning(f"⚠️ 누락된 날짜 {len(missing)}개 발견: {[d.date().isoformat() for d in missing[:10]]}"
                       + (" ..." if len(missing) > 10 else ""))
        else:
            st.caption("✅ 날짜 누락 없음 (연속된 일자 확인 완료)")

        st.dataframe(result.head(10), use_container_width=True)

        st.download_button(
            "📥 shopping_ad_daily.csv 다운로드",
            data=to_csv_bytes(result),
            file_name="shopping_ad_daily.csv",
            mime="text/csv",
            key="dl_daily",
        )
        st.info("다운로드한 파일로 GitHub 리포의 `data/shopping_ad_daily.csv`를 교체(덮어쓰기)하면 됩니다.")


# ════════════════════════════════════════════════════════════════
# TAB 2: 카테고리별 실적 (네이버_쇼검_ep거래액_상세_XXXX.csv)
# ════════════════════════════════════════════════════════════════
with tab2:
    st.markdown("""
    **원본 파일**: `네이버_쇼검_ep거래액_상세_YYYYMMDD.csv` (카테고리별 쇼핑검색광고/EP채널 순결제거래액 상세, UTF-16 탭구분)
    매번 전체 누적 기간이 다시 추출되는 형태이므로, 새로 받은 파일을 그대로 올리면 됩니다.
    """)

    cat_file = st.file_uploader("원본 CSV 업로드 (.csv)", type=["csv"], key="cat_upload")

    if cat_file is not None:
        raw_bytes = cat_file.read()
        text = None
        for enc in ("utf-16", "utf-8-sig", "cp949"):
            try:
                text = raw_bytes.decode(enc)
                break
            except UnicodeDecodeError:
                continue

        if text is None:
            st.error("파일 인코딩을 인식하지 못했습니다 (utf-16 / utf-8 / cp949 시도 실패). 원본 형식을 확인해주세요.")
            st.stop()

        try:
            raw = pd.read_csv(io.StringIO(text), sep="\t", skiprows=2)
        except Exception as e:
            st.error(f"CSV 파싱 실패: {e}")
            st.stop()

        expected_cols = ["ym", "ymd", "category", "광고_이월", "광고_입점", "광고_정상",
                         "EP_이월", "EP_입점", "EP_정상"]
        if raw.shape[1] != len(expected_cols):
            st.error(
                f"컬럼 개수가 예상과 다릅니다 (예상 {len(expected_cols)}개, 실제 {raw.shape[1]}개). "
                "원본 리포트 형식이 바뀌지 않았는지 확인해주세요."
            )
            st.stop()

        raw.columns = expected_cols

        for c in ["광고_이월", "광고_입점", "광고_정상", "EP_이월", "EP_입점", "EP_정상"]:
            raw[c] = raw[c].astype(str).str.replace(",", "").str.replace("nan", "0")
            raw[c] = pd.to_numeric(raw[c], errors="coerce").fillna(0)

        raw["date"] = pd.to_datetime(raw["ymd"], format="%Y%m%d")
        result = raw[["date", "category"] + [c for c in expected_cols if c not in ("ym", "ymd", "category")]]
        result = result.sort_values(["date", "category"]).reset_index(drop=True)

        st.success(
            f"변환 완료: {len(result):,}행 · {result['date'].min().date()} ~ {result['date'].max().date()} "
            f"· 카테고리 {result['category'].nunique()}개"
        )
        st.caption(f"카테고리 목록: {', '.join(sorted(result['category'].unique()))}")

        unique_dates = result["date"].drop_duplicates()
        missing = check_missing_dates(unique_dates)
        if missing:
            st.warning(f"⚠️ 누락된 날짜 {len(missing)}개 발견: {[d.date().isoformat() for d in missing[:10]]}"
                       + (" ..." if len(missing) > 10 else ""))
        else:
            st.caption("✅ 날짜 누락 없음 (연속된 일자 확인 완료)")

        st.dataframe(result.head(10), use_container_width=True)

        st.download_button(
            "📥 category_daily.csv 다운로드",
            data=to_csv_bytes(result),
            file_name="category_daily.csv",
            mime="text/csv",
            key="dl_category",
        )
        st.info("다운로드한 파일로 GitHub 리포의 `data/category_daily.csv`를 교체(덮어쓰기)하면 됩니다.")
